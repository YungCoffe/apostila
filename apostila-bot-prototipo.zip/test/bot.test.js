'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { readCatalog, validFile, GRADES, ACTION } = require('../src/catalog');
const { panel, selection, IDS } = require('../src/ui');
const { makeHandler } = require('../src/handlers');

// Work on an isolated copy so tests remain safe and repeatable after configuration.
const catalog = structuredClone(readCatalog());
for (const group of Object.values(catalog.groups)) for (const f of group.files) { f.url = null; f.watermarked = false; }
test('catálogo tem 7 séries, 6 volumes e 26 arquivos', () => {
  assert.equal(GRADES.length, 7); assert.equal(ACTION.length, 6);
  assert.deepEqual(GRADES.map(([id]) => catalog.groups[id].files.length), [3,3,3,3,3,3,2]);
  assert.equal(Object.values(catalog.groups).reduce((n, g) => n + g.files.length, 0), 26);
  for (const group of Object.values(catalog.groups)) for (const f of group.files) assert.equal(validFile(f), false);
});

test('painel contém dois menus persistentes e banner', () => {
  const p = panel();
  assert.equal(p.components.length, 2);
  assert.equal(p.components[0].components[0].options.length, 7);
  assert.equal(p.components[1].components[0].options.length, 6);
  assert.equal(p.files[0].name, 'banner.png');
  assert.equal(p.embeds[0].image.url, 'attachment://banner.png');
});

test('valida declaração de marca, HTTPS e bloqueia links de origem conhecidos', () => {
  const f = { label: 'Teste', watermarked: true, url: 'https://publico.exemplo.org/marcado.pdf' };
  assert.equal(validFile(f), true);
  for (const bad of [
    { ...f, watermarked: false }, { ...f, url: 'http://publico.exemplo.org/a.pdf' },
    { ...f, url: 'https://user:pass@exemplo.org/a.pdf' }, { ...f, url: 'https://localhost/a.pdf' },
    { ...f, url: 'https://127.0.0.1/a.pdf' }, { ...f, url: 'https://example.org/169678/1781599' },
    { ...f, url: 'https://github.com/YungCoffe/sp-acao-apostilas/releases/download/apostilas-2026/portugues1.pdf' },
  ]) assert.equal(validFile(bad), false, JSON.stringify(bad));
});

test('sem arquivos marcados não expõe nenhum link; parcial alerta e mantém resposta privada', () => {
  const empty = selection(catalog, IDS.grades, '6');
  assert.equal(empty.flags, 64); assert.equal(empty.components, undefined);
  const copy = structuredClone(catalog);
  copy.groups['6'].files[0].url = 'https://publico.exemplo.org/6-1.pdf';
  copy.groups['6'].files[0].watermarked = true;
  const partial = selection(copy, IDS.grades, '6');
  assert.equal(partial.components[0].components.length, 1);
  assert.match(partial.embeds[0].description, /2 arquivo/);
  assert.equal(partial.components[0].components[0].url, 'https://publico.exemplo.org/6-1.pdf');
});

test('valores desconhecidos e menus errados não fornecem arquivos', () => {
  assert.match(selection(catalog, IDS.grades, 'portugues1').content, /não foi possível/i);
  assert.match(selection(catalog, 'outro', '6').content, /não foi possível/i);
  assert.match(selection(catalog, IDS.action, 'em1').content, /não foi possível/i);
});

function interaction(overrides = {}) {
  return { commandName:'apostilas', isChatInputCommand:()=>true, isStringSelectMenu:()=>false,
    inGuild:()=>true, memberPermissions:{has:()=>true}, replies:[],
    async reply(x) { this.replies.push(x); this.replied=true; },
    async deferReply(x) { this.deferred=true; this.deferral=x; },
    async editReply(x) { this.replies.push(x); }, ...overrides };
}
test('admin publica e não admin recebe recusa privada', async () => {
  const handle = makeHandler({readCatalog, adminBit: 8n});
  const admin=interaction(); await handle(admin); assert.equal(admin.replies[0].components.length, 2);
  const user=interaction({memberPermissions:{has:()=>false}}); await handle(user);
  assert.equal(user.replies[0].flags, 64); assert.match(user.replies[0].content,/administradores/);
});
test('menu reconhecido defere privadamente, consulta catálogo e responde', async () => {
  let reads=0; const handle=makeHandler({readCatalog:()=>{ reads++; return catalog; }, adminBit:8n});
  const i=interaction({isChatInputCommand:()=>false,isStringSelectMenu:()=>true,customId:IDS.action,values:['portugues2']});
  await handle(i); assert.equal(i.deferral.flags,64); assert.equal(reads,1);
  assert.match(i.replies[0].embeds[0].title,/Português.*2/);
});
test('catálogo quebrado gera erro privado e não expõe detalhes internos', async () => {
  const handle=makeHandler({readCatalog:()=>{throw Error('segredo');},adminBit:8n,log:()=>{}});
  const i=interaction({isChatInputCommand:()=>false,isStringSelectMenu:()=>true,customId:IDS.grades,values:['6']});
  await handle(i); assert.equal(i.deferred,true); assert.doesNotMatch(i.replies[0].content,/segredo/);
});
